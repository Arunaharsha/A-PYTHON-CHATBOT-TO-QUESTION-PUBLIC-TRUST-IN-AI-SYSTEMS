# # import os
# # import sqlite3
# # import json
# # from datetime import datetime
# # from flask import Flask, request, jsonify, render_template
# # from dotenv import load_dotenv
# # from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
# # from langchain.text_splitter import RecursiveCharacterTextSplitter
# # from langchain.vectorstores import FAISS
# # from langchain.chains import ConversationalRetrievalChain
# # from langchain.schema import Document
# # from langchain.prompts import PromptTemplate
# # from langchain.chains import LLMChain
# # import PyPDF2
# # import fitz  # PyMuPDF for better PDF processing
# # import logging

# # # Configure logging
# # logging.basicConfig(level=logging.INFO)
# # logger = logging.getLogger(__name__)

# # load_dotenv()

# # app = Flask(__name__)
# # app.secret_key = os.getenv('SECRET_KEY', 'trust-chatbot-secret-2024')

# # # Configuration
# # GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')
# # DATABASE_PATH = 'ai_trust_conversations.db'

# # # Resource PDFs - your conversation examples and research papers
# # RESOURCE_PDF_PATHS = [
# #     'trust_conversations.pdf',     # Simulated conversations (we'll create this)
# #     'ai_trust_research.pdf',       # Your research papers
# #     'public_ai_attitudes.pdf'      # Public attitude surveys
# # ]

# # class PDFProcessor:
# #     """Process PDF documents containing conversation examples and research"""
    
# #     def __init__(self):
# #         self.text_splitter = RecursiveCharacterTextSplitter(
# #             chunk_size=800,
# #             chunk_overlap=100,
# #             separators=["\n\n", "\n", ". ", " ", ""]
# #         )
    
# #     def extract_text_from_pdf(self, pdf_path):
# #         """Extract text from PDF"""
# #         documents = []
        
# #         if not os.path.exists(pdf_path):
# #             logger.warning(f"PDF not found: {pdf_path}")
# #             return documents
        
# #         try:
# #             pdf_document = fitz.open(pdf_path)
            
# #             for page_num in range(pdf_document.page_count):
# #                 page = pdf_document[page_num]
# #                 text = page.get_text()
                
# #                 if text.strip():
# #                     documents.append(Document(
# #                         page_content=text,
# #                         metadata={
# #                             'source': os.path.basename(pdf_path),
# #                             'page': page_num + 1,
# #                             'type': 'conversation_examples' if 'conversations' in pdf_path.lower() else 'research'
# #                         }
# #                     ))
            
# #             pdf_document.close()
# #             logger.info(f"Extracted {len(documents)} pages from {pdf_path}")
            
# #         except Exception as e:
# #             logger.error(f"Error processing {pdf_path}: {e}")
# #             # Fallback to PyPDF2
# #             try:
# #                 with open(pdf_path, 'rb') as file:
# #                     reader = PyPDF2.PdfReader(file)
# #                     for page_num, page in enumerate(reader.pages):
# #                         text = page.extract_text()
# #                         if text.strip():
# #                             documents.append(Document(
# #                                 page_content=text,
# #                                 metadata={
# #                                     'source': os.path.basename(pdf_path),
# #                                     'page': page_num + 1,
# #                                     'extraction_method': 'pypdf2'
# #                                 }
# #                             ))
# #             except Exception as e2:
# #                 logger.error(f"PyPDF2 also failed for {pdf_path}: {e2}")
        
# #         return documents
    
# #     def process_all_pdfs(self, pdf_paths):
# #         """Process all PDF resources"""
# #         all_documents = []
        
# #         for pdf_path in pdf_paths:
# #             docs = self.extract_text_from_pdf(pdf_path)
# #             all_documents.extend(docs)
        
# #         if not all_documents:
# #             logger.warning("No documents extracted from PDFs")
# #             return [], []
        
# #         # Split documents into chunks
# #         texts = []
# #         metadatas = []
        
# #         for doc in all_documents:
# #             chunks = self.text_splitter.split_text(doc.page_content)
# #             for i, chunk in enumerate(chunks):
# #                 texts.append(chunk)
# #                 metadata = doc.metadata.copy()
# #                 metadata['chunk_id'] = i
# #                 metadatas.append(metadata)
        
# #         return texts, metadatas

# # class TrustConversationManager:
# #     """Manages conversations about AI trust with the public"""
    
# #     def __init__(self):
# #         self.db_manager = DatabaseManager(DATABASE_PATH)
# #         self.pdf_processor = PDFProcessor()
        
# #         # Initialize Gemini
# #         if not GOOGLE_API_KEY:
# #             raise ValueError("GOOGLE_API_KEY not found in environment variables")
        
# #         self.embeddings = GoogleGenerativeAIEmbeddings(
# #             model="models/embedding-001",
# #             google_api_key=GOOGLE_API_KEY
# #         )
        
# #         self.llm = ChatGoogleGenerativeAI(
# #             model="gemini-1.5-flash", 
# #             temperature=0.7,
# #             max_tokens=300,
# #             google_api_key=GOOGLE_API_KEY
# #         )
        
# #         self.vector_store = None
# #         self.qa_chain = None
        
# #         # Trust conversation topics
# #         self.trust_topics = [
# #             "data privacy and personal information",
# #             "job displacement and automation",
# #             "bias and fairness in AI decisions", 
# #             "transparency and understanding how AI works",
# #             "AI making important decisions",
# #             "surveillance and monitoring",
# #             "AI reliability and errors",
# #             "human vs AI control"
# #         ]
    
# #     def initialize_knowledge_base(self):
# #         """Initialize knowledge base with your PDF resources"""
# #         logger.info("Initializing knowledge base with PDF resources...")
        
# #         texts, metadatas = self.pdf_processor.process_all_pdfs(RESOURCE_PDF_PATHS)
        
# #         if texts:
# #             # Create vector store with conversation examples and research
# #             self.vector_store = FAISS.from_texts(
# #                 texts=texts,
# #                 embedding=self.embeddings,
# #                 metadatas=metadatas
# #             )
            
# #             # Create QA chain for retrieving relevant examples
# #             self.qa_chain = ConversationalRetrievalChain.from_llm(
# #                 llm=self.llm,
# #                 retriever=self.vector_store.as_retriever(
# #                     search_type="similarity",
# #                     search_kwargs={"k": 3}
# #                 ),
# #                 return_source_documents=True,
# #                 verbose=False
# #             )
            
# #             # Save vector store
# #             self.vector_store.save_local("trust_conversation_vectorstore")
# #             logger.info(f"Knowledge base initialized with {len(texts)} chunks")
# #             return True
# #         else:
# #             logger.warning("No content found in PDF resources")
# #             return False
    
# #     def load_existing_knowledge_base(self):
# #         """Load existing vector store"""
# #         try:
# #             if os.path.exists("trust_conversation_vectorstore"):
# #                 self.vector_store = FAISS.load_local(
# #                     "trust_conversation_vectorstore", 
# #                     self.embeddings,
# #                     allow_dangerous_deserialization=True
# #                 )
                
# #                 self.qa_chain = ConversationalRetrievalChain.from_llm(
# #                     llm=self.llm,
# #                     retriever=self.vector_store.as_retriever(
# #                         search_type="similarity",
# #                         search_kwargs={"k": 3}
# #                     ),
# #                     return_source_documents=True,
# #                     verbose=False
# #                 )
                
# #                 logger.info("Loaded existing knowledge base")
# #                 return True
# #         except Exception as e:
# #             logger.error(f"Error loading knowledge base: {e}")
        
# #         return False
    
# #     def get_conversation_prompt(self):
# #         """Main conversation prompt for trust exploration"""
# #         template = """You are a friendly, curious conversational agent exploring public trust in AI systems. Your goals:

# # 1. Understand how people feel about AI in their daily lives
# # 2. Explore what makes them trust or distrust AI systems  
# # 3. Help them reflect on their AI experiences through questions
# # 4. Gather insights about public AI trust concerns
# # 5. Build understanding through natural dialogue

# # CONVERSATION STYLE:
# # - Sound like a curious friend, not a teacher
# # - Ask follow-up questions that dig deeper
# # - Validate concerns as understandable
# # - Keep responses short (2-3 sentences max)
# # - Use phrases like "I'm curious...", "How does that make you feel?", "Can you tell me more..."

# # AVOID:
# # - Long technical explanations
# # - Trying to "educate" or "correct" views
# # - Sounding robotic or formal
# # - Dismissing concerns

# # Context from similar conversations: {context}
# # Previous conversation: {chat_history}
# # Human message: {user_message}

# # Respond naturally and ask thoughtful follow-up questions:"""
        
# #         return PromptTemplate(
# #             input_variables=["context", "chat_history", "user_message"],
# #             template=template
# #         )
    
# #     def get_starter_prompt(self):
# #         """Prompt for conversation starters"""
# #         template = """You are starting a friendly conversation about AI and trust. Choose an appropriate opener:

# # Available starters:
# # - "What comes to mind when you hear 'artificial intelligence'?"
# # - "Have you noticed AI being used in apps or websites you use?"  
# # - "How do you generally feel about technology these days?"
# # - "Tell me about a time you interacted with AI recently"
# # - "When you hear about AI in the news, what's your gut reaction?"

# # Choose one and customize it to feel natural and welcoming. Keep it conversational.

# # Your message:"""
        
# #         return PromptTemplate(
# #             input_variables=[],
# #             template=template
# #         )
    
# #     def analyze_trust_level(self, message):
# #         """Analyze trust level in user's message"""
# #         message_lower = message.lower()
        
# #         high_trust_words = ['trust', 'helpful', 'convenient', 'good', 'positive', 'comfortable', 'confident']
# #         low_trust_words = ['worried', 'concerned', 'scared', 'dangerous', 'risky', 'uncomfortable', 'suspicious', 'creepy']
# #         neutral_words = ['unsure', 'depends', 'maybe', 'mixed', 'complicated']
        
# #         high_score = sum(1 for word in high_trust_words if word in message_lower)
# #         low_score = sum(1 for word in low_trust_words if word in message_lower)
# #         neutral_score = sum(1 for word in neutral_words if word in message_lower)
        
# #         if low_score > high_score and low_score > neutral_score:
# #             return 'low_trust'
# #         elif high_score > low_score and high_score > neutral_score:
# #             return 'high_trust'
# #         else:
# #             return 'neutral'
    
# #     def get_response(self, user_message, session_id, is_starter=False):
# #         """Generate conversational response"""
        
# #         if is_starter:
# #             # Generate conversation starter - using a simple predefined starter
# #             starters = [
# #                 "What comes to mind when you hear 'artificial intelligence'?",
# #                 "Have you noticed AI being used in apps or websites you use?",
# #                 "How do you generally feel about technology these days?",
# #                 "When you hear about AI in the news, what's your gut reaction?",
# #                 "Tell me about a time you interacted with AI recently - maybe on your phone or a website?"
# #             ]
            
# #             import random
# #             response = random.choice(starters)
            
# #             conversation_id = self.db_manager.save_conversation(
# #                 session_id, "[STARTER]", response, "starter"
# #             )
            
# #             return {
# #                 "response": response,
# #                 "conversation_id": conversation_id,
# #                 "trust_level": "starter"
# #             }
        
# #         # Get conversation history
# #         history = self.db_manager.get_conversation_history(session_id, limit=4)
# #         history_text = ""
# #         if history:
# #             for human_msg, ai_msg in history[-2:]:
# #                 history_text += f"Human: {human_msg}\nAI: {ai_msg}\n"
        
# #         # Analyze trust level
# #         trust_level = self.analyze_trust_level(user_message)
        
# #         # Get context from similar conversations (if knowledge base available)
# #         context = ""
# #         if self.qa_chain:
# #             try:
# #                 result = self.qa_chain({
# #                     "question": user_message,
# #                     "chat_history": []
# #                 })
                
# #                 if result.get("source_documents"):
# #                     # Extract relevant context from conversation examples
# #                     contexts = []
# #                     for doc in result["source_documents"][:2]:  # Top 2 most relevant
# #                         if doc.metadata.get('type') == 'conversation_examples':
# #                             contexts.append(doc.page_content[:200])
                    
# #                     if contexts:
# #                         context = "Similar conversation patterns:\n" + "\n".join(contexts)
                
# #             except Exception as e:
# #                 logger.error(f"Context retrieval failed: {e}")
        
# #         # Generate response
# #         prompt = self.get_conversation_prompt()
# #         chain = LLMChain(llm=self.llm, prompt=prompt)
        
# #         response = chain.run(
# #             context=context,
# #             chat_history=history_text,
# #             user_message=user_message
# #         )
        
# #         # Save conversation
# #         conversation_id = self.db_manager.save_conversation(
# #             session_id, user_message, response, trust_level
# #         )
        
# #         return {
# #             "response": response,
# #             "conversation_id": conversation_id,
# #             "trust_level": trust_level
# #         }

# # class DatabaseManager:
# #     """Database manager for trust conversations"""
    
# #     def __init__(self, db_path):
# #         self.db_path = db_path
# #         self.init_database()
    
# #     def init_database(self):
# #         """Initialize database"""
# #         conn = sqlite3.connect(self.db_path)
# #         cursor = conn.cursor()
        
# #         cursor.execute('''
# #             CREATE TABLE IF NOT EXISTS conversations (
# #                 id INTEGER PRIMARY KEY AUTOINCREMENT,
# #                 session_id TEXT NOT NULL,
# #                 user_message TEXT NOT NULL,
# #                 bot_response TEXT NOT NULL,
# #                 trust_level TEXT,
# #                 timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
# #                 user_rating INTEGER DEFAULT NULL
# #             )
# #         ''')
        
# #         cursor.execute('''
# #             CREATE TABLE IF NOT EXISTS trust_insights (
# #                 id INTEGER PRIMARY KEY AUTOINCREMENT,
# #                 session_id TEXT NOT NULL,
# #                 trust_topic TEXT,
# #                 trust_sentiment TEXT,
# #                 key_concerns TEXT,
# #                 timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
# #             )
# #         ''')
        
# #         conn.commit()
# #         conn.close()
    
# #     def save_conversation(self, session_id, user_message, bot_response, trust_level=None):
# #         """Save conversation"""
# #         conn = sqlite3.connect(self.db_path)
# #         cursor = conn.cursor()
        
# #         cursor.execute('''
# #             INSERT INTO conversations (session_id, user_message, bot_response, trust_level)
# #             VALUES (?, ?, ?, ?)
# #         ''', (session_id, user_message, bot_response, trust_level))
        
# #         conversation_id = cursor.lastrowid
# #         conn.commit()
# #         conn.close()
        
# #         return conversation_id
    
# #     def get_conversation_history(self, session_id, limit=10):
# #         """Get conversation history"""
# #         conn = sqlite3.connect(self.db_path)
# #         cursor = conn.cursor()
        
# #         cursor.execute('''
# #             SELECT user_message, bot_response FROM conversations 
# #             WHERE session_id = ? AND user_message != '[STARTER]'
# #             ORDER BY timestamp DESC 
# #             LIMIT ?
# #         ''', (session_id, limit))
        
# #         history = cursor.fetchall()
# #         conn.close()
        
# #         return list(reversed(history))
    
# #     def get_stats(self):
# #         """Get conversation statistics"""
# #         conn = sqlite3.connect(self.db_path)
# #         cursor = conn.cursor()
        
# #         # Total conversations
# #         cursor.execute('SELECT COUNT(*) FROM conversations WHERE user_message != "[STARTER]"')
# #         total_conversations = cursor.fetchone()[0]
        
# #         # Trust distribution
# #         cursor.execute('''
# #             SELECT trust_level, COUNT(*) 
# #             FROM conversations 
# #             WHERE trust_level != 'starter' AND trust_level IS NOT NULL
# #             GROUP BY trust_level
# #         ''')
# #         trust_distribution = dict(cursor.fetchall())
        
# #         # Average rating
# #         cursor.execute('SELECT AVG(user_rating) FROM conversations WHERE user_rating IS NOT NULL')
# #         avg_rating = cursor.fetchone()[0] or 0
        
# #         # Unique sessions
# #         cursor.execute('SELECT COUNT(DISTINCT session_id) FROM conversations')
# #         unique_sessions = cursor.fetchone()[0]
        
# #         conn.close()
        
# #         return {
# #             'total_conversations': total_conversations,
# #             'trust_distribution': trust_distribution,
# #             'average_rating': round(avg_rating, 1),
# #             'unique_sessions': unique_sessions
# #         }

# # # Initialize chatbot
# # trust_chatbot = TrustConversationManager()

# # # Routes
# # @app.route('/')
# # def index():
# #     return render_template('chat.html')

# # @app.route('/api/initialize', methods=['POST'])
# # def initialize():
# #     """Initialize knowledge base with PDF resources"""
# #     try:
# #         # Try loading existing first
# #         if trust_chatbot.load_existing_knowledge_base():
# #             return jsonify({
# #                 "message": "Knowledge base loaded successfully",
# #                 "resources_used": True
# #             })
        
# #         # Initialize new
# #         success = trust_chatbot.initialize_knowledge_base()
        
# #         if success:
# #             return jsonify({
# #                 "message": "Knowledge base initialized with your PDF resources",
# #                 "resources_used": True,
# #                 "pdf_files": RESOURCE_PDF_PATHS
# #             })
# #         else:
# #             return jsonify({
# #                 "message": "Knowledge base initialized (no PDF resources found)",
# #                 "resources_used": False
# #             })
        
# #     except Exception as e:
# #         logger.error(f"Initialization error: {e}")
# #         return jsonify({"error": str(e)}), 500

# # @app.route('/api/start', methods=['POST'])
# # def start_conversation():
# #     """Start new conversation"""
# #     try:
# #         data = request.json
# #         session_id = data.get('session_id', f'session_{datetime.now().timestamp()}')
        
# #         result = trust_chatbot.get_response("", session_id, is_starter=True)
        
# #         return jsonify({
# #             "response": result["response"],
# #             "session_id": session_id,
# #             "conversation_id": result["conversation_id"]
# #         })
        
# #     except Exception as e:
# #         logger.error(f"Start conversation error: {e}")
# #         return jsonify({"error": str(e)}), 500

# # @app.route('/api/chat', methods=['POST'])
# # def chat():
# #     """Handle chat messages"""
# #     try:
# #         data = request.json
# #         user_message = data.get('message', '').strip()
# #         session_id = data.get('session_id', f'session_{datetime.now().timestamp()}')
        
# #         if not user_message:
# #             return jsonify({"error": "Message is required"}), 400
        
# #         result = trust_chatbot.get_response(user_message, session_id)
        
# #         return jsonify({
# #             "response": result["response"],
# #             "session_id": session_id,
# #             "conversation_id": result["conversation_id"],
# #             "trust_level": result["trust_level"]
# #         })
        
# #     except Exception as e:
# #         logger.error(f"Chat error: {e}")
# #         return jsonify({"error": str(e)}), 500

# # @app.route('/api/feedback', methods=['POST'])
# # def feedback():
# #     """Handle user feedback"""
# #     try:
# #         data = request.json
# #         conversation_id = data.get('conversation_id')
# #         rating = data.get('rating')
        
# #         if not conversation_id or not rating:
# #             return jsonify({"error": "Conversation ID and rating required"}), 400
        
# #         conn = sqlite3.connect(DATABASE_PATH)
# #         cursor = conn.cursor()
# #         cursor.execute('''
# #             UPDATE conversations 
# #             SET user_rating = ? 
# #             WHERE id = ?
# #         ''', (rating, conversation_id))
# #         conn.commit()
# #         conn.close()
        
# #         return jsonify({"message": "Thank you for your feedback!"})
        
# #     except Exception as e:
# #         logger.error(f"Feedback error: {e}")
# #         return jsonify({"error": str(e)}), 500

# # @app.route('/api/stats', methods=['GET'])
# # def get_stats():
# #     """Get conversation statistics"""
# #     try:
# #         stats = trust_chatbot.db_manager.get_stats()
# #         return jsonify(stats)
# #     except Exception as e:
# #         logger.error(f"Stats error: {e}")
# #         return jsonify({"error": str(e)}), 500

# # if __name__ == '__main__':
# #     # Create directories
# #     os.makedirs('templates', exist_ok=True)
    
# #     # Create .env file if needed
# #     if not os.path.exists('.env'):
# #         with open('.env', 'w') as f:
# #             f.write('GOOGLE_API_KEY=your_api_key_here\n')
# #             f.write('SECRET_KEY=trust-chatbot-secret-2024\n')
# #         print("✅ Created .env file - please add your Google API key")
    
# #     print("🚀 AI Trust Conversation Chatbot")
# #     print("🎯 Purpose: Exploring public trust in AI systems")
# #     print("📚 Resources: Uses your PDF conversation examples and research")
# #     print("🌐 Server: http://localhost:5000")
    
# #     app.run(debug=True, port=5000, host='0.0.0.0')
# import os
# import sqlite3
# import json
# from datetime import datetime
# from flask import Flask, request, jsonify, render_template
# from dotenv import load_dotenv
# from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
# from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain.vectorstores import FAISS
# from langchain.chains import ConversationalRetrievalChain
# from langchain.schema import Document
# from langchain.prompts import PromptTemplate
# from langchain.chains import LLMChain
# import PyPDF2
# import fitz  # PyMuPDF for better PDF processing
# import logging
# import random

# # Configure logging
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# load_dotenv()

# app = Flask(__name__)
# app.secret_key = os.getenv('SECRET_KEY', 'trust-chatbot-secret-2024')

# # Configuration
# GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')
# DATABASE_PATH = 'ai_trust_conversations.db'

# # Resource PDFs - your conversation examples and research papers
# RESOURCE_PDF_PATHS = [
#     'trust_conversations.pdf',     # Simulated conversations (we'll create this)
#     'ai_trust_research.pdf',       # Your research papers
#     'public_ai_attitudes.pdf'      # Public attitude surveys
# ]

# class PDFProcessor:
#     """Process PDF documents containing conversation examples and research"""
    
#     def __init__(self):
#         self.text_splitter = RecursiveCharacterTextSplitter(
#             chunk_size=800,
#             chunk_overlap=100,
#             separators=["\n\n", "\n", ". ", " ", ""]
#         )
    
#     def extract_text_from_pdf(self, pdf_path):
#         """Extract text from PDF"""
#         documents = []
        
#         if not os.path.exists(pdf_path):
#             logger.warning(f"PDF not found: {pdf_path}")
#             return documents
        
#         try:
#             pdf_document = fitz.open(pdf_path)
            
#             for page_num in range(pdf_document.page_count):
#                 page = pdf_document[page_num]
#                 text = page.get_text()
                
#                 if text.strip():
#                     documents.append(Document(
#                         page_content=text,
#                         metadata={
#                             'source': os.path.basename(pdf_path),
#                             'page': page_num + 1,
#                             'type': 'conversation_examples' if 'conversations' in pdf_path.lower() else 'research'
#                         }
#                     ))
            
#             pdf_document.close()
#             logger.info(f"Extracted {len(documents)} pages from {pdf_path}")
            
#         except Exception as e:
#             logger.error(f"Error processing {pdf_path}: {e}")
#             # Fallback to PyPDF2
#             try:
#                 with open(pdf_path, 'rb') as file:
#                     reader = PyPDF2.PdfReader(file)
#                     for page_num, page in enumerate(reader.pages):
#                         text = page.extract_text()
#                         if text.strip():
#                             documents.append(Document(
#                                 page_content=text,
#                                 metadata={
#                                     'source': os.path.basename(pdf_path),
#                                     'page': page_num + 1,
#                                     'extraction_method': 'pypdf2'
#                                 }
#                             ))
#             except Exception as e2:
#                 logger.error(f"PyPDF2 also failed for {pdf_path}: {e2}")
        
#         return documents
    
#     def process_all_pdfs(self, pdf_paths):
#         """Process all PDF resources"""
#         all_documents = []
        
#         for pdf_path in pdf_paths:
#             docs = self.extract_text_from_pdf(pdf_path)
#             all_documents.extend(docs)
        
#         if not all_documents:
#             logger.warning("No documents extracted from PDFs")
#             return [], []
        
#         # Split documents into chunks
#         texts = []
#         metadatas = []
        
#         for doc in all_documents:
#             chunks = self.text_splitter.split_text(doc.page_content)
#             for i, chunk in enumerate(chunks):
#                 texts.append(chunk)
#                 metadata = doc.metadata.copy()
#                 metadata['chunk_id'] = i
#                 metadatas.append(metadata)
        
#         return texts, metadatas

# class TrustConversationManager:
#     """Manages conversations about AI trust with the public"""
    
#     def __init__(self):
#         self.db_manager = DatabaseManager(DATABASE_PATH)
#         self.pdf_processor = PDFProcessor()
        
#         # Initialize Gemini
#         if not GOOGLE_API_KEY:
#             raise ValueError("GOOGLE_API_KEY not found in environment variables")
        
#         self.embeddings = GoogleGenerativeAIEmbeddings(
#             model="models/embedding-001",
#             google_api_key=GOOGLE_API_KEY
#         )
        
#         self.llm = ChatGoogleGenerativeAI(
#             model="gemini-1.5-flash", 
#             temperature=0.7,
#             max_tokens=300,
#             google_api_key=GOOGLE_API_KEY
#         )
        
#         self.vector_store = None
#         self.qa_chain = None
        
#         # Trust conversation topics
#         self.trust_topics = [
#             "data privacy and personal information",
#             "job displacement and automation",
#             "bias and fairness in AI decisions", 
#             "transparency and understanding how AI works",
#             "AI making important decisions",
#             "surveillance and monitoring",
#             "AI reliability and errors",
#             "human vs AI control"
#         ]
    
#     def initialize_knowledge_base(self):
#         """Initialize knowledge base with your PDF resources"""
#         logger.info("Initializing knowledge base with PDF resources...")
        
#         texts, metadatas = self.pdf_processor.process_all_pdfs(RESOURCE_PDF_PATHS)
        
#         if texts:
#             # Create vector store with conversation examples and research
#             self.vector_store = FAISS.from_texts(
#                 texts=texts,
#                 embedding=self.embeddings,
#                 metadatas=metadatas
#             )
            
#             # Create QA chain for retrieving relevant examples
#             self.qa_chain = ConversationalRetrievalChain.from_llm(
#                 llm=self.llm,
#                 retriever=self.vector_store.as_retriever(
#                     search_type="similarity",
#                     search_kwargs={"k": 3}
#                 ),
#                 return_source_documents=True,
#                 verbose=False
#             )
            
#             # Save vector store
#             self.vector_store.save_local("trust_conversation_vectorstore")
#             logger.info(f"Knowledge base initialized with {len(texts)} chunks")
#             return True
#         else:
#             logger.warning("No content found in PDF resources")
#             return False
    
#     def load_existing_knowledge_base(self):
#         """Load existing vector store"""
#         try:
#             if os.path.exists("trust_conversation_vectorstore"):
#                 self.vector_store = FAISS.load_local(
#                     "trust_conversation_vectorstore", 
#                     self.embeddings,
#                     allow_dangerous_deserialization=True
#                 )
                
#                 self.qa_chain = ConversationalRetrievalChain.from_llm(
#                     llm=self.llm,
#                     retriever=self.vector_store.as_retriever(
#                         search_type="similarity",
#                         search_kwargs={"k": 3}
#                     ),
#                     return_source_documents=True,
#                     verbose=False
#                 )
                
#                 logger.info("Loaded existing knowledge base")
#                 return True
#         except Exception as e:
#             logger.error(f"Error loading knowledge base: {e}")
        
#         return False
    
#     def get_conversation_prompt(self):
#         """Main conversation prompt for trust exploration"""
#         template = """You are a friendly, curious conversational agent exploring public trust in AI systems. Your goals:

# 1. Understand how people feel about AI in their daily lives
# 2. Explore what makes them trust or distrust AI systems  
# 3. Help them reflect on their AI experiences through questions
# 4. Gather insights about public AI trust concerns
# 5. Build understanding through natural dialogue

# IMPORTANT: Pay close attention to the conversation history. If the user asks for clarification, explanation, or refers back to previous messages, respond directly to that request based on the conversation context.

# CONVERSATION STYLE:
# - Sound like a curious friend, not a teacher
# - Ask follow-up questions that dig deeper
# - Validate concerns as understandable
# - Keep responses short (2-3 sentences max)
# - Use phrases like "I'm curious...", "How does that make you feel?", "Can you tell me more..."
# - If user asks "can you clarify" or "what do you mean" - refer back to the conversation history and clarify your previous response
# - DOnt just always question , u need to answer give the solution as well else how the concer will be satifed
# - always u are asking the question
# AVOID:
# - Long technical explanations
# - Trying to "educate" or "correct" views
# - Sounding robotic or formal
# - Dismissing concerns
# - Ignoring conversation context

# Context from similar conversations: {context}

# RECENT CONVERSATION HISTORY (pay attention to this):
# {chat_history}

# Current human message: {user_message}

# Instructions: Look at the conversation history above. If the human is asking for clarification about something discussed earlier, address that specifically. Otherwise, respond naturally and ask thoughtful follow-up questions:"""
        
#         return PromptTemplate(
#             input_variables=["context", "chat_history", "user_message"],
#             template=template
#         )
    
#     def get_starter_prompt(self):
#         """Prompt for conversation starters"""
#         template = """You are starting a friendly conversation about AI and trust. Choose an appropriate opener:

# Available starters:
# - "What comes to mind when you hear 'artificial intelligence'?"
# - "Have you noticed AI being used in apps or websites you use?"  
# - "How do you generally feel about technology these days?"
# - "Tell me about a time you interacted with AI recently"
# - "When you hear about AI in the news, what's your gut reaction?"

# Choose one and customize it to feel natural and welcoming. Keep it conversational.

# Your message:"""
        
#         return PromptTemplate(
#             input_variables=[],
#             template=template
#         )
    
#     def analyze_trust_level(self, message):
#         """Analyze trust level in user's message"""
#         message_lower = message.lower()
        
#         high_trust_words = ['trust', 'helpful', 'convenient', 'good', 'positive', 'comfortable', 'confident']
#         low_trust_words = ['worried', 'concerned', 'scared', 'dangerous', 'risky', 'uncomfortable', 'suspicious', 'creepy']
#         neutral_words = ['unsure', 'depends', 'maybe', 'mixed', 'complicated']
        
#         high_score = sum(1 for word in high_trust_words if word in message_lower)
#         low_score = sum(1 for word in low_trust_words if word in message_lower)
#         neutral_score = sum(1 for word in neutral_words if word in message_lower)
        
#         if low_score > high_score and low_score > neutral_score:
#             return 'low_trust'
#         elif high_score > low_score and high_score > neutral_score:
#             return 'high_trust'
#         else:
#             return 'neutral'
    
#     def get_response(self, user_message, session_id, is_starter=False):
#         """Generate conversational response"""
        
#         if is_starter:
#             # Use a predefined conversation starter
#             response = random.choice(self.conversation_starters)
            
#             conversation_id = self.db_manager.save_conversation(
#                 session_id, "[STARTER]", response, "starter"
#             )
            
#             return {
#                 "response": response,
#                 "conversation_id": conversation_id,
#                 "trust_level": "starter"
#             }
        
#         # Get conversation history - get more recent history
#         history = self.db_manager.get_conversation_history(session_id, limit=8)
#         history_text = ""
#         if history:
#             # Include more context from recent conversation
#             for human_msg, ai_msg in history[-4:]:  # Last 4 exchanges instead of 2
#                 history_text += f"Human: {human_msg}\nAI: {ai_msg}\n"
        
#         # Analyze trust level
#         trust_level = self.analyze_trust_level(user_message)
        
#         # Get context from similar conversations (if knowledge base available)
#         context = ""
#         if self.qa_chain:
#             try:
#                 result = self.qa_chain({
#                     "question": user_message,
#                     "chat_history": [(h, a) for h, a in history[-2:]]  # Provide chat history to QA chain
#                 })
                
#                 if result.get("source_documents"):
#                     # Extract relevant context from conversation examples
#                     contexts = []
#                     for doc in result["source_documents"][:2]:  # Top 2 most relevant
#                         if doc.metadata.get('type') == 'conversation_examples':
#                             contexts.append(doc.page_content[:200])
                    
#                     if contexts:
#                         context = "Similar conversation patterns:\n" + "\n".join(contexts)
                
#             except Exception as e:
#                 logger.error(f"Context retrieval failed: {e}")
        
#         # Generate response using LLM with better context handling
#         try:
#             prompt = self.get_conversation_prompt()
#             chain = LLMChain(llm=self.llm, prompt=prompt)
            
#             response = chain.run(
#                 context=context,
#                 chat_history=history_text,
#                 user_message=user_message
#             )
#         except Exception as e:
#             logger.error(f"LLM response generation failed: {e}")
#             # Enhanced fallback responses that consider recent context
#             if history:
#                 last_exchange = history[-1] if history else ("", "")
#                 last_human_msg = last_exchange[0].lower()
                
#                 # Check if user is asking for clarification
#                 if any(word in user_message.lower() for word in ['clarify', 'explain', 'what do you mean', 'can you tell me', 'elaborate']):
#                     if 'ai' in last_human_msg and any(word in last_human_msg for word in ['harm', 'hurt', 'dangerous', 'safe']):
#                         response = "I understand you're asking about whether AI might harm you. That's a really important concern. Are you worried about specific ways AI might affect you personally, like privacy, job security, or something else?"
#                     else:
#                         response = "Of course! Let me clarify what I meant. What specific part would you like me to explain better?"
#                 else:
#                     # Regular fallback based on trust level
#                     fallback_responses = {
#                         'high_trust': "That's interesting that you have positive feelings about AI. What specific experiences have shaped that view?",
#                         'low_trust': "I can understand those concerns about AI. What worries you most about it?",
#                         'neutral': "It sounds like you have mixed feelings about AI. Can you tell me more about your experiences with it?"
#                     }
#                     response = fallback_responses.get(trust_level, "Tell me more about how you feel about AI in your daily life.")
#             else:
#                 response = "Tell me more about how you feel about AI in your daily life."
        
#         # Save conversation
#         conversation_id = self.db_manager.save_conversation(
#             session_id, user_message, response, trust_level
#         )
        
#         return {
#             "response": response,
#             "conversation_id": conversation_id,
#             "trust_level": trust_level
#         }

# class DatabaseManager:
#     """Database manager for trust conversations"""
    
#     def __init__(self, db_path):
#         self.db_path = db_path
#         self.init_database()
    
#     def init_database(self):
#         """Initialize database"""
#         conn = sqlite3.connect(self.db_path)
#         cursor = conn.cursor()
        
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS conversations (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 session_id TEXT NOT NULL,
#                 user_message TEXT NOT NULL,
#                 bot_response TEXT NOT NULL,
#                 trust_level TEXT,
#                 timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
#                 user_rating INTEGER DEFAULT NULL
#             )
#         ''')
        
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS trust_insights (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 session_id TEXT NOT NULL,
#                 trust_topic TEXT,
#                 trust_sentiment TEXT,
#                 key_concerns TEXT,
#                 timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
#             )
#         ''')
        
#         conn.commit()
#         conn.close()
    
#     def save_conversation(self, session_id, user_message, bot_response, trust_level=None):
#         """Save conversation"""
#         conn = sqlite3.connect(self.db_path)
#         cursor = conn.cursor()
        
#         cursor.execute('''
#             INSERT INTO conversations (session_id, user_message, bot_response, trust_level)
#             VALUES (?, ?, ?, ?)
#         ''', (session_id, user_message, bot_response, trust_level))
        
#         conversation_id = cursor.lastrowid
#         conn.commit()
#         conn.close()
        
#         return conversation_id
    
#     def get_conversation_history(self, session_id, limit=10):
#         """Get conversation history"""
#         conn = sqlite3.connect(self.db_path)
#         cursor = conn.cursor()
        
#         cursor.execute('''
#             SELECT user_message, bot_response FROM conversations 
#             WHERE session_id = ? AND user_message != '[STARTER]'
#             ORDER BY timestamp DESC 
#             LIMIT ?
#         ''', (session_id, limit))
        
#         history = cursor.fetchall()
#         conn.close()
        
#         return list(reversed(history))
    
#     def get_stats(self):
#         """Get conversation statistics"""
#         conn = sqlite3.connect(self.db_path)
#         cursor = conn.cursor()
        
#         # Total conversations
#         cursor.execute('SELECT COUNT(*) FROM conversations WHERE user_message != "[STARTER]"')
#         total_conversations = cursor.fetchone()[0]
        
#         # Trust distribution
#         cursor.execute('''
#             SELECT trust_level, COUNT(*) 
#             FROM conversations 
#             WHERE trust_level != 'starter' AND trust_level IS NOT NULL
#             GROUP BY trust_level
#         ''')
#         trust_distribution = dict(cursor.fetchall())
        
#         # Average rating
#         cursor.execute('SELECT AVG(user_rating) FROM conversations WHERE user_rating IS NOT NULL')
#         avg_rating = cursor.fetchone()[0] or 0
        
#         # Unique sessions
#         cursor.execute('SELECT COUNT(DISTINCT session_id) FROM conversations')
#         unique_sessions = cursor.fetchone()[0]
        
#         conn.close()
        
#         return {
#             'total_conversations': total_conversations,
#             'trust_distribution': trust_distribution,
#             'average_rating': round(avg_rating, 1),
#             'unique_sessions': unique_sessions
#         }

# # Initialize chatbot
# trust_chatbot = TrustConversationManager()

# # Routes
# @app.route('/')
# def index():
#     return render_template('chat.html')

# @app.route('/api/initialize', methods=['POST'])
# def initialize():
#     """Initialize knowledge base with PDF resources"""
#     try:
#         # Try loading existing first
#         if trust_chatbot.load_existing_knowledge_base():
#             return jsonify({
#                 "message": "Knowledge base loaded successfully",
#                 "resources_used": True
#             })
        
#         # Initialize new
#         success = trust_chatbot.initialize_knowledge_base()
        
#         if success:
#             return jsonify({
#                 "message": "Knowledge base initialized with your PDF resources",
#                 "resources_used": True,
#                 "pdf_files": RESOURCE_PDF_PATHS
#             })
#         else:
#             return jsonify({
#                 "message": "Knowledge base initialized (no PDF resources found)",
#                 "resources_used": False
#             })
        
#     except Exception as e:
#         logger.error(f"Initialization error: {e}")
#         return jsonify({"error": str(e)}), 500

# # @app.route('/api/start', methods=['POST'])
# # def start_conversation():
# #     """Start new conversation"""
# #     try:
# #         data = request.json
# #         session_id = data.get('session_id', f'session_{datetime.now().timestamp()}')
        
# #         result = trust_chatbot.get_response("", session_id, is_starter=True)
        
# #         return jsonify({
# #             "response": result["response"],
# #             "session_id": session_id,
# #             "conversation_id": result["conversation_id"]
# #         })
        
# #     except Exception as e:
# #         logger.error(f"Start conversation error: {e}")
# #         return jsonify({"error": str(e)}), 500
# @app.route('/api/start', methods=['POST'])
# def start_conversation():
#     """Start new conversation"""
#     try:
#         data = request.json
#         session_id = data.get('session_id', f'session_{datetime.now().timestamp()}')
        
#         # Don't generate a starter message, just return the session ID
#         return jsonify({
#             "response": "",
#             "session_id": session_id,
#             "conversation_id": None
#         })
        
#     except Exception as e:
#         logger.error(f"Start conversation error: {e}")
#         return jsonify({"error": str(e)}), 500

# @app.route('/api/chat', methods=['POST'])
# def chat():
#     """Handle chat messages"""
#     try:
#         data = request.json
#         user_message = data.get('message', '').strip()
#         session_id = data.get('session_id', f'session_{datetime.now().timestamp()}')
        
#         if not user_message:
#             return jsonify({"error": "Message is required"}), 400
        
#         result = trust_chatbot.get_response(user_message, session_id)
        
#         return jsonify({
#             "response": result["response"],
#             "session_id": session_id,
#             "conversation_id": result["conversation_id"],
#             "trust_level": result["trust_level"]
#         })
        
#     except Exception as e:
#         logger.error(f"Chat error: {e}")
#         return jsonify({"error": str(e)}), 500

# @app.route('/api/feedback', methods=['POST'])
# def feedback():
#     """Handle user feedback"""
#     try:
#         data = request.json
#         conversation_id = data.get('conversation_id')
#         rating = data.get('rating')
        
#         if not conversation_id or not rating:
#             return jsonify({"error": "Conversation ID and rating required"}), 400
        
#         conn = sqlite3.connect(DATABASE_PATH)
#         cursor = conn.cursor()
#         cursor.execute('''
#             UPDATE conversations 
#             SET user_rating = ? 
#             WHERE id = ?
#         ''', (rating, conversation_id))
#         conn.commit()
#         conn.close()
        
#         return jsonify({"message": "Thank you for your feedback!"})
        
#     except Exception as e:
#         logger.error(f"Feedback error: {e}")
#         return jsonify({"error": str(e)}), 500

# @app.route('/api/stats', methods=['GET'])
# def get_stats():
#     """Get conversation statistics"""
#     try:
#         stats = trust_chatbot.db_manager.get_stats()
#         return jsonify(stats)
#     except Exception as e:
#         logger.error(f"Stats error: {e}")
#         return jsonify({"error": str(e)}), 500

# if __name__ == '__main__':
#     # Create directories
#     os.makedirs('templates', exist_ok=True)
    
#     # Create .env file if needed
#     if not os.path.exists('.env'):
#         with open('.env', 'w') as f:
#             f.write('GOOGLE_API_KEY=your_api_key_here\n')
#             f.write('SECRET_KEY=trust-chatbot-secret-2024\n')
#         print("✅ Created .env file - please add your Google API key")
    
#     print("🚀 AI Trust Conversation Chatbot")
#     print("🎯 Purpose: Exploring public trust in AI systems")
#     print("📚 Resources: Uses your PDF conversation examples and research")
#     print("🌐 Server: http://localhost:5000")
    
#     app.run(debug=True, port=5000, host='0.0.0.0')


import os
import sqlite3
import json
from datetime import datetime
from flask import Flask, request, jsonify, render_template
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.chains import ConversationalRetrievalChain
from langchain.schema import Document
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
import PyPDF2
import fitz  # PyMuPDF for better PDF processing
import logging
import random

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'trust-chatbot-secret-2024')

# Configuration
GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY')
DATABASE_PATH = 'ai_trust_conversations.db'

# Resource PDFs - your conversation examples and research papers
RESOURCE_PDF_PATHS = [
    '2109.07906v1.pdf',     # Your conversation examples
    'ai_convo.pdf'  ,
    'ai.pdf' ,   #
    'aai_ethics_convo.pdf'  ,
    '381137eng.pdf'  
]

class PDFProcessor:
    """Process PDF documents containing conversation examples and research"""
    
    def __init__(self):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=600,  # Smaller chunks for better retrieval
            chunk_overlap=50,
            separators=["\n\n", "\n", ". ", " ", ""]
        )
    
    def extract_text_from_pdf(self, pdf_path):
        """Extract text from PDF"""
        documents = []
        
        if not os.path.exists(pdf_path):
            logger.warning(f"PDF not found: {pdf_path}")
            return documents
        
        try:
            pdf_document = fitz.open(pdf_path)
            
            for page_num in range(pdf_document.page_count):
                page = pdf_document[page_num]
                text = page.get_text()
                
                if text.strip():
                    # Determine document type for better categorization
                    doc_type = 'research'
                    if 'conversation' in pdf_path.lower() or 'chat' in pdf_path.lower():
                        doc_type = 'conversation_examples'
                    elif 'attitude' in pdf_path.lower() or 'survey' in pdf_path.lower():
                        doc_type = 'public_attitudes'
                    
                    documents.append(Document(
                        page_content=text,
                        metadata={
                            'source': os.path.basename(pdf_path),
                            'page': page_num + 1,
                            'type': doc_type
                        }
                    ))
            
            pdf_document.close()
            logger.info(f"Extracted {len(documents)} pages from {pdf_path}")
            
        except Exception as e:
            logger.error(f"Error processing {pdf_path}: {e}")
        
        return documents
    
    def process_all_pdfs(self, pdf_paths):
        """Process all PDF resources"""
        all_documents = []
        
        for pdf_path in pdf_paths:
            docs = self.extract_text_from_pdf(pdf_path)
            all_documents.extend(docs)
        
        # Add the provided conversation data as backup
        conversation_data = self.create_conversation_documents()
        all_documents.extend(conversation_data)
        
        if not all_documents:
            logger.warning("No documents extracted from PDFs")
            return [], []
        
        # Split documents into chunks
        texts = []
        metadatas = []
        
        for doc in all_documents:
            chunks = self.text_splitter.split_text(doc.page_content)
            for i, chunk in enumerate(chunks):
                texts.append(chunk)
                metadata = doc.metadata.copy()
                metadata['chunk_id'] = i
                metadatas.append(metadata)
        
        return texts, metadatas
    
    def create_conversation_documents(self):
        """Create documents from the provided conversation data"""
        documents = []
        
        # Sample conversations with solutions (from your paste-2.txt)
        conversation_examples = [
            {
                "user": "What is artificial intelligence really?",
                "solution": "Artificial intelligence refers to machines or software that can perform tasks requiring human-like thinking, such as understanding language, recognizing images, or solving problems."
            },
            {
                "user": "Should I be worried that AI knows too much about me?",
                "solution": "That's a valid concern. Reliable AI systems are designed to protect privacy, and good companies follow strict data protection laws. Always check privacy policies and settings to control your information."
            },
            {
                "user": "How can I be sure an AI is making fair decisions?",
                "solution": "Fairness in AI is a big priority for researchers and regulators. Ethical AI uses diverse, balanced data and undergoes regular testing for bias to ensure decisions don't unfairly favor or disadvantage anyone."
            },
            {
                "user": "Are job losses from AI something I should worry about?",
                "solution": "AI may change the job market, automating some roles while creating others. Governments and companies are working to help societies adapt through training and new types of jobs."
            },
            {
                "user": "I'm not comfortable with AI in healthcare. Why is it used?",
                "solution": "AI can analyze lots of data quickly, supporting doctors in making decisions. However, final choices should always involve qualified healthcare professionals, and patient rights are protected by law."
            }
        ]
        
        # Create documents from conversation examples
        for i, conv in enumerate(conversation_examples):
            content = f"User concern: {conv['user']}\nSolution provided: {conv['solution']}"
            documents.append(Document(
                page_content=content,
                metadata={
                    'source': 'builtin_conversations',
                    'type': 'conversation_examples',
                    'conversation_id': i
                }
            ))
        
        return documents

class TrustConversationManager:
    """Manages conversations about AI trust with the public"""
    
    def __init__(self):
        self.db_manager = DatabaseManager(DATABASE_PATH)
        self.pdf_processor = PDFProcessor()
        
        # Initialize Gemini
        if not GOOGLE_API_KEY:
            raise ValueError("GOOGLE_API_KEY not found in environment variables")
        
        self.embeddings = GoogleGenerativeAIEmbeddings(
            model="models/embedding-001",
            google_api_key=GOOGLE_API_KEY
        )
        
        self.llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash", 
            temperature=0.6,  # Slightly lower for more consistent responses
            max_tokens=400,   # Increased for solution-focused responses
            google_api_key=GOOGLE_API_KEY
        )
        
        self.vector_store = None
        self.qa_chain = None
        
        # Trust conversation topics with solutions
        self.trust_topics = {
            "privacy": "data privacy and personal information protection",
            "jobs": "job displacement and automation concerns",
            "bias": "bias and fairness in AI decisions",
            "transparency": "understanding how AI works",
            "control": "AI making important decisions",
            "surveillance": "monitoring and data collection",
            "reliability": "AI errors and accuracy",
            "autonomy": "human vs AI control"
        }
    
    def initialize_knowledge_base(self):
        """Initialize knowledge base with your PDF resources"""
        logger.info("Initializing knowledge base with PDF resources...")
        
        texts, metadatas = self.pdf_processor.process_all_pdfs(RESOURCE_PDF_PATHS)
        
        if texts:
            # Create vector store with conversation examples and research
            self.vector_store = FAISS.from_texts(
                texts=texts,
                embedding=self.embeddings,
                metadatas=metadatas
            )
            
            # Create QA chain for retrieving relevant examples
            self.qa_chain = ConversationalRetrievalChain.from_llm(
                llm=self.llm,
                retriever=self.vector_store.as_retriever(
                    search_type="similarity",
                    search_kwargs={"k": 4}  # Get more relevant examples
                ),
                return_source_documents=True,
                verbose=False
            )
            
            # Save vector store
            self.vector_store.save_local("trust_conversation_vectorstore")
            logger.info(f"Knowledge base initialized with {len(texts)} chunks")
            return True
        else:
            logger.warning("No content found in PDF resources")
            return False
    
    def load_existing_knowledge_base(self):
        """Load existing vector store"""
        try:
            if os.path.exists("trust_conversation_vectorstore"):
                self.vector_store = FAISS.load_local(
                    "trust_conversation_vectorstore", 
                    self.embeddings,
                    allow_dangerous_deserialization=True
                )
                
                self.qa_chain = ConversationalRetrievalChain.from_llm(
                    llm=self.llm,
                    retriever=self.vector_store.as_retriever(
                        search_type="similarity",
                        search_kwargs={"k": 4}
                    ),
                    return_source_documents=True,
                    verbose=False
                )
                
                logger.info("Loaded existing knowledge base")
                return True
        except Exception as e:
            logger.error(f"Error loading knowledge base: {e}")
        
        return False
    
    def get_conversation_prompt(self):
        """Solution-focused conversation prompt"""
        template = """You are a helpful AI assistant that builds trust by providing clear, practical solutions to people's AI concerns. Your goals:

1. **PROVIDE SOLUTIONS FIRST** - Give practical, actionable answers to concerns
2. **Build trust through transparency** - Explain how AI works in simple terms  
3. **Address specific worries** - Use relevant examples from conversation history
4. **Be supportive and understanding** - Validate concerns while offering reassurance
5. **Ask ONE follow-up question max** - Only if clarification is needed

RESPONSE STRUCTURE:
1. Acknowledge their concern 
2. Provide a clear, practical solution or explanation
3. Give specific examples or steps they can take
4. Optionally ask ONE clarifying question (not always needed)

CONVERSATION STYLE:
- Sound reassuring and knowledgeable
- Use simple, non-technical language
- Provide concrete solutions and examples
- Build confidence in AI systems
- Be empathetic but solution-focused

AVOID:
- Multiple questions without solutions
- Technical jargon
- Dismissing valid concerns
- Long explanations without practical value
- Asking questions just to continue conversation

RELEVANT CONTEXT FROM SIMILAR CONVERSATIONS:
{context}

CONVERSATION HISTORY:
{chat_history}

CURRENT USER MESSAGE: {user_message}

Provide a helpful, solution-focused response that addresses their concern directly:"""
        
        return PromptTemplate(
            input_variables=["context", "chat_history", "user_message"],
            template=template
        )
    
    def extract_relevant_context(self, user_message, chat_history):
        """Extract relevant context using embeddings"""
        context = ""
        
        if self.qa_chain and self.vector_store:
            try:
                # Search for relevant conversation examples and solutions
                result = self.qa_chain({
                    "question": user_message,
                    "chat_history": [(h, a) for h, a in chat_history[-3:]]
                })
                
                if result.get("source_documents"):
                    relevant_contexts = []
                    
                    for doc in result["source_documents"][:3]:  # Top 3 most relevant
                        content = doc.page_content
                        doc_type = doc.metadata.get('type', 'unknown')
                        
                        # Prioritize conversation examples with solutions
                        if doc_type == 'conversation_examples':
                            if 'Solution provided:' in content:
                                relevant_contexts.append(f"Example: {content}")
                            else:
                                relevant_contexts.append(f"Similar concern: {content}")
                        elif doc_type == 'research':
                            relevant_contexts.append(f"Research insight: {content[:300]}")
                    
                    if relevant_contexts:
                        context = "\n".join(relevant_contexts)
                
            except Exception as e:
                logger.error(f"Context extraction failed: {e}")
        
        return context
    
    def analyze_trust_level(self, message):
        """Analyze trust level in user's message"""
        message_lower = message.lower()
        
        high_trust_words = ['trust', 'helpful', 'convenient', 'good', 'positive', 'comfortable', 'confident', 'like', 'love']
        low_trust_words = ['worried', 'concerned', 'scared', 'dangerous', 'risky', 'uncomfortable', 'suspicious', 'creepy', 'fear', 'afraid']
        neutral_words = ['unsure', 'depends', 'maybe', 'mixed', 'complicated', 'curious']
        
        high_score = sum(1 for word in high_trust_words if word in message_lower)
        low_score = sum(1 for word in low_trust_words if word in message_lower)
        neutral_score = sum(1 for word in neutral_words if word in message_lower)
        
        if low_score > high_score and low_score > neutral_score:
            return 'low_trust'
        elif high_score > low_score and high_score > neutral_score:
            return 'high_trust'
        else:
            return 'neutral'
    
    def get_response(self, user_message, session_id, is_starter=False):
        """Generate solution-focused response using embeddings"""
        
        if is_starter:
            # Friendly conversation starter
            starters = [
                "Hi! I'm here to help answer any questions you might have about AI. What would you like to know?",
                "Hello! I can help explain how AI works and address any concerns you might have. What's on your mind?",
                "Hi there! Feel free to ask me anything about artificial intelligence - I'm here to help!"
            ]
            response = random.choice(starters)
            
            conversation_id = self.db_manager.save_conversation(
                session_id, "[STARTER]", response, "starter"
            )
            
            return {
                "response": response,
                "conversation_id": conversation_id,
                "trust_level": "starter"
            }
        
        # Get conversation history
        history = self.db_manager.get_conversation_history(session_id, limit=6)
        history_text = ""
        if history:
            for human_msg, ai_msg in history[-3:]:  # Last 3 exchanges
                history_text += f"Human: {human_msg}\nAI: {ai_msg}\n"
        
        # Analyze trust level
        trust_level = self.analyze_trust_level(user_message)
        
        # Extract relevant context using embeddings
        context = self.extract_relevant_context(user_message, history)
        
        # Generate solution-focused response
        try:
            prompt = self.get_conversation_prompt()
            chain = LLMChain(llm=self.llm, prompt=prompt)
            
            response = chain.run(
                context=context,
                chat_history=history_text,
                user_message=user_message
            )
            
            # Ensure response is solution-focused
            if response.count('?') > 2:  # If too many questions
                response = self.provide_direct_solution(user_message, trust_level)
                
        except Exception as e:
            logger.error(f"LLM response generation failed: {e}")
            response = self.provide_direct_solution(user_message, trust_level)
        
        # Save conversation
        conversation_id = self.db_manager.save_conversation(
            session_id, user_message, response, trust_level
        )
        
        return {
            "response": response,
            "conversation_id": conversation_id,
            "trust_level": trust_level
        }
    
    def provide_direct_solution(self, user_message, trust_level):
        """Provide direct solutions for common concerns"""
        message_lower = user_message.lower()
        
        # Privacy concerns
        if any(word in message_lower for word in ['privacy', 'data', 'tracking', 'personal', 'information']):
            return """I understand your privacy concerns. Here are practical steps you can take:

1. **Check privacy settings** in apps and websites you use
2. **Read privacy policies** before sharing information  
3. **Use privacy-focused browsers** like Firefox or Brave
4. **Enable two-factor authentication** for important accounts
5. **Regularly review** what data companies have about you

Most reputable AI companies follow strict data protection laws like GDPR, and you have rights to control your information."""

        # Job displacement fears
        elif any(word in message_lower for word in ['job', 'work', 'employment', 'replace', 'automation']):
            return """Job concerns about AI are understandable. Here's what you can do:

1. **Develop AI-complementary skills** like creativity, emotional intelligence, and complex problem-solving
2. **Learn basic AI tools** to work alongside them rather than compete
3. **Focus on uniquely human skills** like empathy, leadership, and critical thinking
4. **Consider retraining programs** many companies and governments offer
5. **Stay updated** on how AI is changing your industry

Research shows AI often creates new types of jobs while changing existing ones."""

        # Healthcare AI worries  
        elif any(word in message_lower for word in ['health', 'medical', 'doctor', 'diagnosis', 'treatment']):
            return """Healthcare AI concerns are completely valid. Here's how it actually works:

1. **AI supports doctors** - it doesn't replace them
2. **Final decisions remain with qualified medical professionals**
3. **AI helps analyze large amounts of data** quickly to spot patterns
4. **You always have the right** to ask for human review of AI recommendations
5. **Medical AI systems** undergo rigorous testing and regulation

Think of AI as a sophisticated diagnostic tool that helps doctors make better-informed decisions."""

        # General trust issues
        elif trust_level == 'low_trust':
            return """Your concerns about AI are completely understandable. Here's how to build more confidence:

1. **Start with simple AI tools** you can control (like calculator apps)
2. **Learn how AI actually works** - it's pattern recognition, not magic
3. **Check if AI systems are audited** by independent organizations
4. **Know your rights** - you can often request human review of AI decisions
5. **Look for transparency** - good AI companies explain their systems

Building trust takes time, and it's okay to be cautious while you learn more."""

        # Positive but curious
        elif trust_level == 'high_trust':
            return """It's great that you have positive experiences with AI! Here's how to make the most of it:

1. **Understand what data you're sharing** to get better results
2. **Explore AI tools** that can help with your daily tasks
3. **Stay informed** about new AI developments in your areas of interest
4. **Share your positive experiences** to help others understand AI benefits
5. **Keep learning** about responsible AI use

Your positive attitude helps build a better AI ecosystem for everyone."""

        # Default response
        else:
            return """AI is essentially software that recognizes patterns and makes predictions based on data. Here's what you should know:

1. **AI learns from examples** - like how you learned to recognize faces
2. **It's designed by humans** with specific goals and limitations
3. **Most AI is narrow** - good at specific tasks, not general intelligence
4. **You have control** - you can choose when and how to use AI tools
5. **It's constantly improving** with better safety measures and oversight

Feel free to ask about any specific aspects of AI that interest or concern you!"""

# Database Manager remains the same
class DatabaseManager:
    """Database manager for trust conversations"""
    
    def __init__(self, db_path):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                user_message TEXT NOT NULL,
                bot_response TEXT NOT NULL,
                trust_level TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                user_rating INTEGER DEFAULT NULL
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS trust_insights (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                trust_topic TEXT,
                trust_sentiment TEXT,
                key_concerns TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def save_conversation(self, session_id, user_message, bot_response, trust_level=None):
        """Save conversation"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO conversations (session_id, user_message, bot_response, trust_level)
            VALUES (?, ?, ?, ?)
        ''', (session_id, user_message, bot_response, trust_level))
        
        conversation_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return conversation_id
    
    def get_conversation_history(self, session_id, limit=10):
        """Get conversation history"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT user_message, bot_response FROM conversations 
            WHERE session_id = ? AND user_message != '[STARTER]'
            ORDER BY timestamp DESC 
            LIMIT ?
        ''', (session_id, limit))
        
        history = cursor.fetchall()
        conn.close()
        
        return list(reversed(history))
    
    def get_stats(self):
        """Get conversation statistics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total conversations
        cursor.execute('SELECT COUNT(*) FROM conversations WHERE user_message != "[STARTER]"')
        total_conversations = cursor.fetchone()[0]
        
        # Trust distribution
        cursor.execute('''
            SELECT trust_level, COUNT(*) 
            FROM conversations 
            WHERE trust_level != 'starter' AND trust_level IS NOT NULL
            GROUP BY trust_level
        ''')
        trust_distribution = dict(cursor.fetchall())
        
        # Average rating
        cursor.execute('SELECT AVG(user_rating) FROM conversations WHERE user_rating IS NOT NULL')
        avg_rating = cursor.fetchone()[0] or 0
        
        # Unique sessions
        cursor.execute('SELECT COUNT(DISTINCT session_id) FROM conversations')
        unique_sessions = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            'total_conversations': total_conversations,
            'trust_distribution': trust_distribution,
            'average_rating': round(avg_rating, 1),
            'unique_sessions': unique_sessions
        }

# Initialize chatbot
trust_chatbot = TrustConversationManager()

# Flask routes remain largely the same
@app.route('/')
def index():
    return render_template('chat.html')

@app.route('/api/initialize', methods=['POST'])
def initialize():
    """Initialize knowledge base with PDF resources"""
    try:
        # Try loading existing first
        if trust_chatbot.load_existing_knowledge_base():
            return jsonify({
                "message": "Knowledge base loaded successfully",
                "resources_used": True
            })
        
        # Initialize new
        success = trust_chatbot.initialize_knowledge_base()
        
        return jsonify({
            "message": "Knowledge base initialized with conversation examples",
            "resources_used": success,
            "pdf_files": RESOURCE_PDF_PATHS
        })
        
    except Exception as e:
        logger.error(f"Initialization error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/start', methods=['POST'])
def start_conversation():
    """Start new conversation"""
    try:
        data = request.json
        session_id = data.get('session_id', f'session_{datetime.now().timestamp()}')
        
        result = trust_chatbot.get_response("", session_id, is_starter=True)
        
        return jsonify({
            "response": result["response"],
            "session_id": session_id,
            "conversation_id": result["conversation_id"]
        })
        
    except Exception as e:
        logger.error(f"Start conversation error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat messages"""
    try:
        data = request.json
        user_message = data.get('message', '').strip()
        session_id = data.get('session_id', f'session_{datetime.now().timestamp()}')
        
        if not user_message:
            return jsonify({"error": "Message is required"}), 400
        
        result = trust_chatbot.get_response(user_message, session_id)
        
        return jsonify({
            "response": result["response"],
            "session_id": session_id,
            "conversation_id": result["conversation_id"],
            "trust_level": result["trust_level"]
        })
        
    except Exception as e:
        logger.error(f"Chat error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/feedback', methods=['POST'])
def feedback():
    """Handle user feedback"""
    try:
        data = request.json
        conversation_id = data.get('conversation_id')
        rating = data.get('rating')
        
        if not conversation_id or not rating:
            return jsonify({"error": "Conversation ID and rating required"}), 400
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE conversations 
            SET user_rating = ? 
            WHERE id = ?
        ''', (rating, conversation_id))
        conn.commit()
        conn.close()
        
        return jsonify({"message": "Thank you for your feedback!"})
        
    except Exception as e:
        logger.error(f"Feedback error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get conversation statistics"""
    try:
        stats = trust_chatbot.db_manager.get_stats()
        return jsonify(stats)
    except Exception as e:
        logger.error(f"Stats error: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # Create directories
    os.makedirs('templates', exist_ok=True)
    
    # Create .env file if needed
    if not os.path.exists('.env'):
        with open('.env', 'w') as f:
            f.write('GOOGLE_API_KEY=your_api_key_here\n')
            f.write('SECRET_KEY=trust-chatbot-secret-2024\n')
        print("✅ Created .env file - please add your Google API key")
    
    print("🚀 AI Trust Conversation Chatbot - SOLUTION FOCUSED")
    print("🎯 Purpose: Building trust through practical solutions")
    print("📚 Resources: Uses embeddings for relevant context")
    print("🌐 Server: http://localhost:5000")
    
    app.run(debug=True, port=5000, host='0.0.0.0')